let menu = document.querySelector('#menu-btn');
let navbar = document.querySelector('.header .navbar');

class Cliente {
    constructor(nome, endereco, contato, id, senha, dependentes) {
        this.nome = nome;
        this.endereco = endereco;
        this.contato = contato;
        this.id = id;
        this.senha = senha;
        this.dependentes = dependentes;
    }
}

class Quarto {
    constructor(numero, tipo, codigo = null, preco, dono = null) {
        this.numero = numero;
        this.tipo = tipo;
        this.codigo = codigo;
        this.preco = preco;
        this.dono = dono;
    }
}

class Historico {
    constructor(reserva) {
        this.reserva = reserva;
    }
}

class Comanda {
    constructor(diaria, frigobar = null, servicos = null) {
        this.diaria = diaria;
        this.frigobar = frigobar;
        this.servicos = servicos;
    }
}

class Funcionario {
    constructor(nome, endereco, contato, id) {
        this.nome = nome;
        this.endereco = endereco;
        this.contato = contato;
        this.id = id;
    }
}

class Reserva {
    constructor(checkin, checkout, id, numquarto) {
        this.checkin = new Date(checkin);
        this.checkout = new Date(checkout);
        this.id = id;
        this.numquarto = numquarto;
    }
}
let lista_historico = [];
let lista_reservas = [];
let lista_quartos = {
    executivo: [],
    executivo_vista_mar: [],
    familia: [],
    praiano: [],
    premium: [],
    luxo: []
};
let lista_clientes = [];

// Função para atualizar o localStorage
function salvarDados() {
    localStorage.setItem('lista_historico', JSON.stringify(lista_historico));
    localStorage.setItem('lista_reservas', JSON.stringify(lista_reservas));
    localStorage.setItem('lista_quartos', JSON.stringify(lista_quartos));
    alert(`teste1${lista_clientes}`)
    localStorage.setItem('lista_clientes', JSON.stringify(lista_clientes));
}

// Função para carregar dados do localStorage
function carregarDados() {
    try {
        lista_historico = JSON.parse(localStorage.getItem('lista_historico')) || [];
        lista_reservas = JSON.parse(localStorage.getItem('lista_reservas')) || [];
        lista_quartos = JSON.parse(localStorage.getItem('lista_quartos')) || {
            executivo: [], executivo_vista_mar: [], familia: [], praiano: [], premium: [], luxo: []
        };
        lista_clientes = JSON.parse(localStorage.getItem('lista_clientes')) || [];
        alert(`Lista de clientes: ${JSON.stringify(lista_clientes)}`)
    } catch (error) {
        alert(`Erro ao carregar dados do localStorage: ${error}`);
        // Inicializa as listas em caso de erro
        lista_historico = [];
        lista_reservas = [];
        lista_quartos = {
            executivo: [], executivo_vista_mar: [], familia: [], praiano: [], premium: [], luxo: []
        };
        lista_clientes = [];
    }
}


menu.onclick = () => {
    menu.classList.toggle('fa-times');
    navbar.classList.toggle('active');
}

window.onscroll = () => {
    menu.classList.remove('fa-times');
    navbar.classList.remove('active');
}

var swiper = new Swiper(".home-slider", {
    grabCursor: true,
    loop: true,
    centeredSlides: true,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
});

var swiper = new Swiper(".room-slider", {
    spaceBetween: 20,
    grabCursor: true,
    loop: true,
    centeredSlides: true,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    breakpoints: {
        0: { slidesPerView: 1 },
        768: { slidesPerView: 2 },
        991: { slidesPerView: 3 },
    },
});

var swiper = new Swiper(".gallery-slider", {
    spaceBetween: 10,
    grabCursor: true,
    loop: true,
    centeredSlides: true,
    autoplay: {
        delay: 1500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    breakpoints: {
        0: { slidesPerView: 1 },
        768: { slidesPerView: 3 },
        991: { slidesPerView: 4 },
    },
});

var swiper = new Swiper(".review-slider", {
    spaceBetween: 10,
    grabCursor: true,
    loop: true,
    centeredSlides: true,
    autoplay: {
        delay: 7500,
        disableOnInteraction: false,
    },
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
});

let accordions = document.querySelectorAll('.faqs .row .content .box');

accordions.forEach(acco => {
    acco.onclick = () => {
        accordions.forEach(subAcco => { subAcco.classList.remove('active') });
        acco.classList.add('active');
    }
});

function Cadastro() {
    try {
        let nome = document.getElementById("nome").value;
        let senha = document.getElementById("senha").value;
        let endereco = document.getElementById("endereco").value;
        let contato = document.getElementById("contato").value;
        let id = document.getElementById("id").value;
        let acomp = document.getElementById("acompanhantes").value;
        alert("fase1")
        if (!nome || !senha || !endereco || !contato || !id || acomp === "") {
            alert("Por favor, preencha todos os campos obrigatórios.");
            return;
        }

        if (lista_clientes.some(cliente => cliente.id === id)) {
            alert("O usuário já está cadastrado.");
            return false;
        } else {
            alert("deu certo")
            let cliente = new Cliente(nome, endereco, contato, id, senha, acomp);
            lista_clientes.push(cliente);
            salvarDados();
            window.location.href = 'login.html';
            carregarDados()
        }
    } catch (error) {
        alert("Ocorreu um erro durante o cadastro. Por favor, tente novamente.");
        return false;
    }
}

function Encontrar_pessoa(identidade, senha) {
    return lista_clientes.find(cliente => cliente.id === identidade && cliente.senha === senha) || null;
}

function Encontrar_pessoa_pelo_nome(nome, A) {
    alert("funcao")
    try {
        alert(lista_clientes.find(cliente => cliente.nome === nome))
        return lista_clientes.find(cliente => cliente.nome === nome) || null;
    } catch (error) {
        console.error("Ocorreu um erro durante a busca:", error);
        alert("Ocorreu um erro durante a busca. Por favor, tente novamente.");
        return null; // Retorna null em caso de erro
    }   
}
function DiffDias(datacheckin, datacheckout) {
    let checkin = new Date(datacheckin);
    let checkout = new Date(datacheckout);
    return (checkout - checkin) / (1000 * 60 * 60 * 24);
}

function Login() {
    try {
        alert("fase1");
        carregarDados();  // Certifique-se de que os dados estão carregados.
        alert("fase2");
        alert(`Lista:${lista_clientes}`)
        let nome = document.getElementById("Usuario").value;
        let senha = document.getElementById("Senha").value;
        let objeto = Encontrar_pessoa_pelo_nome(nome,lista_clientes);
        alert("fase3");
        alert(`${objeto}`)
        if (objeto === null) {
            alert("Conta não existente.");
        } else if (objeto.senha === senha) {
            alert(`Entrada com sucesso ${objeto.nome}`);
            window.location.href = 'index.html';
        } else {
            alert("Senha incorreta.");
        }
    } catch (error) {
        alert(`Ocorreu um erro durante o login:${error}` );
        alert("Ocorreu um erro durante o login. Por favor, tente novamente.");
    }
}

function Redirect_cadastro() {
    window.location.href = 'cadastro.html';
}

// window.Redirect_cadastro = Redirect_cadastro;

for (let i = 1; i <= 2; i++) {
    lista_quartos.executivo.push(new Quarto(i, "executivo", null, 1, null));
    lista_quartos.executivo_vista_mar.push(new Quarto(i, "executivo_vista_mar", null, 12, null));
    lista_quartos.familia.push(new Quarto(i, "familia", null, 7, null));
    lista_quartos.praiano.push(new Quarto(i, "praiano", null, 8, null));
    lista_quartos.premium.push(new Quarto(i, "premium", null, 16, null));
    lista_quartos.luxo.push(new Quarto(i, "luxo", null, 15, null));
}

let aux;

function AdicionarReserva() {
    let datacheckin = document.getElementById("datacheckin").value;
    let datacheckout = document.getElementById("datacheckout").value;
    let dono = document.getElementById("nomeReserva").value;
    let tipo = document.getElementById("tipo").value;

    if (EstaDisponivel(datacheckin, datacheckout, tipo)) {
        let x = Encontrar_pessoa_pelo_nome(dono);
        dono = x.id;
        let reserva = new Reserva(datacheckin, datacheckout, dono, aux);
        lista_reservas.push(reserva);
        salvarDados();
    } else {
        alert("Não há quartos disponíveis nessa data ou você digitou uma data inválida");
    }
}

function EstaDisponivel(datacheckin, datacheckout, tipo) {
    let checkin = new Date(datacheckin);
    let checkout = new Date(datacheckout);

    for (let quarto of lista_quartos[tipo]) {
        let status = true;

        for (let reserva of lista_reservas) {
            if (reserva.numquarto === quarto.numero) {
                if (checkin <= reserva.checkout && checkout >= reserva.checkin) {
                    status = false;
                    break;
                }
            }
        }

        if (status) {
            let div = document.getElementById("vazia");
            div.innerText = `Quarto ${quarto.numero} está liberado.`;
            aux = quarto.numero;
            return status;
        }
    }

    return false;
}

function Retirada(id, numquarto, senha) {
    const pessoa = Encontrar_pessoa(id, senha);
    for (let reserva of lista_reservas) {
        if (reserva.numero === numquarto && reserva.id === id && pessoa.senha === senha) {
            lista_historico.push(reserva);
            let index = lista_reservas.findIndex(item => item === reserva);
            if (index !== -1) {
                lista_reservas.splice(index, 1);
                salvarDados();
            }
        }
    }
}

document.querySelectorAll(".mudar-formulario").forEach((elemento) => {
    elemento.addEventListener("click", () => {
        document.getElementById("login").classList.toggle("formulario-visivel");
        document.getElementById("registro").classList.toggle("formulario-visivel");
        document.getElementById("mensagemLogin").classList.toggle("formulario-visivel");
        document.getElementById("mensagemRegistro").classList.toggle("formulario-visivel");
    });
});